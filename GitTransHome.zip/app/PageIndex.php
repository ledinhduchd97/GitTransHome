<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PageIndex extends Model
{
    protected $fillable = [
        'name', 'value'
    ];
}
