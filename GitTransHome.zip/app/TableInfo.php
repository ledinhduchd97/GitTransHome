<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TableInfo extends Model
{
    protected $fillable = [
        'column_1',
        'column_2',
        'column_3',
    ];
}
