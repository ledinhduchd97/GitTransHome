<?php

namespace App\Http\Controllers;

use App\TableInfo;
use Illuminate\Http\Request;

class TableInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TableInfo  $tableInfo
     * @return \Illuminate\Http\Response
     */
    public function show(TableInfo $tableInfo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TableInfo  $tableInfo
     * @return \Illuminate\Http\Response
     */
    public function edit(TableInfo $tableInfo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TableInfo  $tableInfo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TableInfo $tableInfo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TableInfo  $tableInfo
     * @return \Illuminate\Http\Response
     */
    public function destroy(TableInfo $tableInfo)
    {
        //
    }
}
